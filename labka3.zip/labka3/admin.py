from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(Review)
admin.site.register(Book)
admin.site.register(Publisher)
admin.site.register(BookContributor)


class ContributorAdmin(admin.ModelAdmin):
    list_display = ('last_names', 'first_names')
    list_filter = ('last_names',)
    search_fields = ('last_names__startswith', 'first_names')


admin.site.register(Contributor, ContributorAdmin)